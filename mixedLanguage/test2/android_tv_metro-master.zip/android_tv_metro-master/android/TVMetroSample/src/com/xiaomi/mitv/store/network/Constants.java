package com.xiaomi.mitv.store.network;

public class Constants {

    public static final String KEY = "d668d3a268b64c41b3d91c6ab48ba5f9";
    public static final String TOKEN = "efa9ee751f4d454297a2ec7c488b4ceb";
    public static final String SSEC = "310ac586866e45278212bd2e4d0c5bff";

}
