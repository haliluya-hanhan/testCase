package com.xiaomi.mitv.store.bluetooth;


public interface OnHandlerCheckResult {
	public void onCheckFinish(boolean hasConnectedDevice);
}
