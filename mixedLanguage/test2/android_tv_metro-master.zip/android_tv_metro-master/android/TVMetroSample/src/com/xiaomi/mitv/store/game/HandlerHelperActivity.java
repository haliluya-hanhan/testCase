package com.xiaomi.mitv.store.game;

import android.app.Activity;

/**
 * Created by game center on 9/9/14.
 */
public class HandlerHelperActivity extends Activity {
}
