package com.tv.ui.metro.model;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by tv metro on 9/22/14.
 */
public class Preload implements Serializable {
    private static final long serialVersionUID = 1L;
    ArrayList<String>   images;
}

