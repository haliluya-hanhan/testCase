package com.tv.ui.metro.idata;

/**
 * TODO
 */
public class ReportManager {
}
