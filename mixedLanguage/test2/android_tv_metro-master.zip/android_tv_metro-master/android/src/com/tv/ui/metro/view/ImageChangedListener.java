package com.tv.ui.metro.view;

import android.widget.ImageView;

public interface ImageChangedListener {
	void onImageChanged(ImageView view);
}
