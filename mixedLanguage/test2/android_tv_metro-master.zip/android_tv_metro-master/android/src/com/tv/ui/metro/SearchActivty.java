package com.tv.ui.metro;

import android.app.Activity;

/**
 * Created by liuhuadong on 7/29/14.
 */
public class SearchActivty extends Activity {
}
